let colors = require('./lib/public/colors')
module.exports = (colors.__esModule ? colors : { default: colors }).default
