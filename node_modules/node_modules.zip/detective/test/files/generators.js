var a = require('a');

function *gen() {
  yield require('b');
}