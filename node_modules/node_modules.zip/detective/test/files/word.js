var a = load('a');
var b = load('b');
var c = load('c');
var abc = a.b(c);

var EventEmitter = load('events').EventEmitter;

var x = load('doom')(5,6,7);
x(8,9);
c.load('notthis');
var y = load('y') * 100;

var EventEmitter2 = load('events2').EventEmitter();
